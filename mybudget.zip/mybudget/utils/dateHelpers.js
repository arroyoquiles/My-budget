// ── Date helpers ──────────────────────────────────────────────────────────────

const fmd = d => {
  const m = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return `${m[d.getMonth()]} ${d.getDate()}`;
};

const dateStr = d => {
  const y = d.getFullYear(),
        mo = String(d.getMonth()+1).padStart(2,"0"),
        dy = String(d.getDate()).padStart(2,"0");
  return `${y}-${mo}-${dy}`;
};

// Days until day-of-month `dia` (next occurrence on or after today)
const getDU = dia => {
  if (!dia) return null;
  const h = new Date(); h.setHours(0,0,0,0);
  const c = new Date(h.getFullYear(), h.getMonth(), parseInt(dia));
  if (c < h) c.setMonth(c.getMonth()+1);
  return Math.ceil((c - h) / 86400000);
};

// Date object for next occurrence of day-of-month `dia`
const gdf = dia => {
  if (!dia) return null;
  const h = new Date(); h.setHours(0,0,0,0);
  const c = new Date(h.getFullYear(), h.getMonth(), parseInt(dia));
  if (c < h) c.setMonth(c.getMonth()+1);
  return c;
};
