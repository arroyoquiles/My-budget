// ── Pay period engine ─────────────────────────────────────────────────────────

const parseAnchor = anchor => {
  const [y, m, d] = anchor.split("-").map(Number);
  const dt = new Date(y, m-1, d); dt.setHours(0,0,0,0); return dt;
};

const getPaydaysInMonth = (anchor, freq, yr, mth) => {
  if (freq === "semimonthly") return [new Date(yr,mth,1), new Date(yr,mth,15)];
  if (freq === "monthly") {
    const base = parseAnchor(anchor);
    const last = new Date(yr, mth+1, 0).getDate();
    return [new Date(yr, mth, Math.min(base.getDate(), last))];
  }
  const step = freq === "weekly" ? 7 : 14;
  const base = parseAnchor(anchor);
  const monthStart = new Date(yr, mth, 1);
  const monthEnd   = new Date(yr, mth+1, 0); monthEnd.setHours(23,59,59,999);
  const diffDays   = Math.round((monthStart.getTime() - base.getTime()) / 86400000);
  const startN     = Math.ceil(diffDays / step);
  const days = [];
  for (let i = startN; i <= startN+8; i++) {
    const pd = new Date(base.getTime() + i*step*86400000);
    if (pd > monthEnd) break;
    if (pd >= monthStart) days.push(pd);
  }
  return days;
};

const getCurrentPeriodStart = (anchor, freq) => {
  const today = new Date(); today.setHours(0,0,0,0);
  if (freq === "semimonthly") {
    const d1  = new Date(today.getFullYear(), today.getMonth(), 1);
    const d15 = new Date(today.getFullYear(), today.getMonth(), 15);
    return today >= d15 ? d15 : d1;
  }
  if (freq === "monthly") {
    const base = parseAnchor(anchor);
    let pday = new Date(today.getFullYear(), today.getMonth(), base.getDate());
    if (pday > today) pday = new Date(pday.getFullYear(), pday.getMonth()-1, base.getDate());
    return pday;
  }
  const step = freq === "weekly" ? 7 : 14;
  const base = parseAnchor(anchor);
  const diffDays   = Math.round((today.getTime() - base.getTime()) / 86400000);
  const periodsDone = today >= base ? Math.floor(diffDays / step) : 0;
  return new Date(base.getTime() + periodsDone*step*86400000);
};

const getNextPayday = (anchor, freq) => {
  const today = new Date(); today.setHours(0,0,0,0);
  if (freq === "semimonthly") {
    const d15 = new Date(today.getFullYear(), today.getMonth(), 15);
    const nm1 = new Date(today.getFullYear(), today.getMonth()+1, 1);
    return today >= d15 ? nm1 : d15;
  }
  if (freq === "monthly") {
    const base = parseAnchor(anchor);
    let pday = new Date(today.getFullYear(), today.getMonth(), base.getDate());
    if (pday > today) pday = new Date(pday.getFullYear(), pday.getMonth()-1, base.getDate());
    return new Date(pday.getFullYear(), pday.getMonth()+1, base.getDate());
  }
  const step = freq === "weekly" ? 7 : 14;
  const base = parseAnchor(anchor);
  const diffDays    = Math.round((today.getTime() - base.getTime()) / 86400000);
  const periodsDone = today >= base ? Math.floor(diffDays / step) : 0;
  const curStart    = new Date(base.getTime() + periodsDone*step*86400000);
  return new Date(curStart.getTime() + step*86400000);
};

const getUpcomingPaydays = (anchor, count=8, freq="biweekly") => {
  const today = new Date(); today.setHours(0,0,0,0);
  const days = [];
  if (freq === "semimonthly") {
    let d = new Date(today.getFullYear(), today.getMonth(), 1);
    while (days.length < count) {
      const d1  = new Date(d.getFullYear(), d.getMonth(), 1);
      const d15 = new Date(d.getFullYear(), d.getMonth(), 15);
      if (d1 >= today) days.push(new Date(d1));
      if (d15 >= today && days.length < count) days.push(new Date(d15));
      d = new Date(d.getFullYear(), d.getMonth()+1, 1);
    }
    return days.slice(0, count);
  }
  if (freq === "monthly") {
    const base = parseAnchor(anchor);
    let d = new Date(today.getFullYear(), today.getMonth(), base.getDate());
    if (d < today) d = new Date(d.getFullYear(), d.getMonth()+1, base.getDate());
    while (days.length < count) { days.push(new Date(d)); d = new Date(d.getFullYear(), d.getMonth()+1, d.getDate()); }
    return days;
  }
  const step = freq === "weekly" ? 7 : 14;
  const base = parseAnchor(anchor);
  const diffDays    = Math.round((today.getTime() - base.getTime()) / 86400000);
  const periodsDone = today >= base ? Math.floor(diffDays / step) : 0;
  const curStart    = new Date(base.getTime() + periodsDone*step*86400000);
  let cur = new Date(curStart.getTime() + step*86400000);
  while (days.length < count) { days.push(new Date(cur)); cur = new Date(cur.getTime() + step*86400000); }
  return days.slice(0, count);
};

const buildMonthPeriods = (anchor, freq) => {
  const today = new Date(); today.setHours(0,0,0,0);
  const yr = today.getFullYear(), mth = today.getMonth();
  const paydays  = getPaydaysInMonth(anchor, freq, yr, mth);
  const curStart = getCurrentPeriodStart(anchor, freq);
  const curKey   = "period_" + dateStr(curStart);
  let curIdx = -1;
  paydays.forEach((pd, i) => { if ("period_"+dateStr(pd) === curKey) curIdx = i; });
  return paydays.map((pd, i) => ({
    id:          "period_" + dateStr(pd),
    payday:      pd,
    label:       `Check ${i+1}`,
    num:         i+1,
    isCurrent:   "period_"+dateStr(pd) === curKey,
    isUpcoming:  curIdx >= 0 ? i === curIdx+1 : i === 0,
    statusLabel: "period_"+dateStr(pd) === curKey ? "Current"
                 : (curIdx >= 0 && i === curIdx+1 ? "Upcoming" : null),
  }));
};
