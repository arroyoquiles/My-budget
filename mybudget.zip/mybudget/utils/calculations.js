// ── Financial calculations ────────────────────────────────────────────────────

const n = v => parseFloat(v) || 0;

const fmt = v => new Intl.NumberFormat("en-US", {
  style:"currency", currency:"USD", maximumFractionDigits:0
}).format(v || 0);

const fmtD = v => new Intl.NumberFormat("en-US", {
  style:"currency", currency:"USD", minimumFractionDigits:2, maximumFractionDigits:2
}).format(v || 0);

const calcLoan = (balance, apr, pmt) => {
  const b = n(balance), r = n(apr)/100/12, p = n(pmt);
  if (b <= 0 || p <= 0) return { interest:0, principal:0, newBalance:0 };
  const interest = b * r;
  const principal = Math.min(p - interest, b);
  return {
    interest:   Math.max(0, interest),
    principal:  Math.max(0, principal),
    newBalance: Math.max(0, b - principal),
  };
};
