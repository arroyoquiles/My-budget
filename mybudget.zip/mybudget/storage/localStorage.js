// ── Storage key ───────────────────────────────────────────────────────────────
const SK = "mybudget_v17";

// ── Default data ──────────────────────────────────────────────────────────────
const DD = {
  proximoCobro: "2026-04-03", payFreq: "biweekly", theme: "dark",
  checkAmount: 1520,
  periods: {},
  tarjetas: [
    {id:1, nombre:"Prime Card",  balance:676,  limite:700,  minimo:29,  interes:29.49, fechaCorte:"26", fechaPago:"18", historial:[], tipo:"card"},
    {id:2, nombre:"Quicksilver", balance:404,  limite:400,  minimo:50,  interes:28.99, fechaCorte:"2",  fechaPago:"27", historial:[], tipo:"card"},
    {id:3, nombre:"BJ's Card",   balance:1979, limite:2000, minimo:100, interes:28.49, fechaCorte:"13", fechaPago:"7",  historial:[], tipo:"card"},
  ],
  loans: [{id:101, nombre:"Auto Loan (Exeter)", balance:26568, original:27728, minimo:687, interes:22.61, fechaPago:"20", historial:[], tipo:"loan"}],
  pots: {savings_acct:0, emergency:0, investment:0},
  potMovements: [], snapshots: [], ahorro: null, _sa: "",
};

// ── Migration ─────────────────────────────────────────────────────────────────
const migrate = raw => {
  if (!raw) return null;
  const dm = {savings:"savings_acct",directo:"rent",temporal:"temp",ninguno:"other",tarjeta:"credit_card",savings_acct:"savings_acct",credit_card:"credit_card",rent:"rent",utilities:"utilities",auto:"auto",insurance:"insurance",groceries:"groceries",subscription:"subscription",gas:"gas",emergency:"emergency",investment:"investment",temp:"temp",other:"other"};
  const cm = {carro:"auto",vivienda:"rent",servicios:"subscription",gas:"gas",tarjeta:"credit_card",comida:"groceries",otro:"other",auto:"auto",rent:"rent",subscription:"subscription",credit_card:"credit_card",groceries:"groceries",other:"other",insurance:"insurance",utilities:"utilities"};
  const mg = g => ({...g, cat:cm[g.cat]||cm[g.categoria]||"other", destino:dm[g.destino]||"other", diaPago:g.diaPago||null, tarjetaRef:g.tarjetaRef||"", state:g.state||(g.pagado?"paid":"pending"), _quick:g._quick||false});

  const anchor = raw.proximoCobro || "2026-04-03";
  const freq   = raw.payFreq || "biweekly";
  let periods  = raw.periods || {};

  if (!raw.periods) {
    const curStart = getCurrentPeriodStart(anchor, freq);
    const curKey   = "period_" + dateStr(curStart);
    let prevStart;
    if (freq === "semimonthly") {
      const d1  = new Date(curStart.getFullYear(), curStart.getMonth(), 1);
      const d15 = new Date(curStart.getFullYear(), curStart.getMonth(), 15);
      prevStart = curStart.getDate() === 15 ? d1 : new Date(curStart.getFullYear(), curStart.getMonth()-1, 15);
    } else if (freq === "monthly") {
      prevStart = new Date(curStart.getFullYear(), curStart.getMonth()-1, curStart.getDate());
    } else {
      const step = (freq === "weekly" ? 7 : 14) * 86400000;
      prevStart = new Date(curStart.getTime() - step);
    }
    const prevKey     = "period_" + dateStr(prevStart);
    const legacyChecks = raw.checks || [{id:"c1",num:1},{id:"c2",num:2}];
    legacyChecks.forEach((c, i) => {
      const gastos = (raw[`${c.id}_gastos`]||raw[`check${c.num}_gastos`]||raw[`cheque${c.num}_gastos`]||[]).map(mg);
      const amt    = n(raw[c.id]||raw[`check${c.num}`]||raw[`cheque${c.num}`]||0);
      if (gastos.length > 0 || amt > 0) {
        const key = i === 0 ? curKey : prevKey;
        if (!periods[key]) periods[key] = {gastos:[]};
        periods[key].gastos = [...(periods[key].gastos||[]), ...gastos];
      }
    });
    const defaultAmt = n(raw.c1||raw.c2||raw.check1||raw.check2||raw.cheque1||raw.cheque2||1520);
    if (!raw.checkAmount) raw.checkAmount = defaultAmt;
  } else {
    Object.keys(periods).forEach(k => {
      if (periods[k].gastos) periods[k] = {...periods[k], gastos: periods[k].gastos.map(mg)};
    });
  }

  return {
    proximoCobro: anchor,
    payFreq:      freq,
    theme:        raw.theme || "dark",
    checkAmount:  n(raw.checkAmount||raw.c1||raw.c2||raw.check1||raw.check2||raw.cheque1||raw.cheque2||1520),
    periods,
    tarjetas:     (raw.tarjetas||[]).map(t => ({...t, fechaPago:t.fechaPago||"", fechaCorte:t.fechaCorte||"", historial:t.historial||[], tipo:"card"})),
    loans:        (raw.loans||DD.loans).map(l => ({...l, tipo:"loan"})),
    pots:         raw.pots || {savings_acct:0, emergency:0, investment:0},
    potMovements: raw.potMovements || [],
    snapshots:    raw.snapshots || [],
    ahorro:       raw.ahorro || null,
    _sa:          raw._sa || "",
  };
};

const loadData = () => {
  try {
    const s = localStorage.getItem(SK);
    if (s) return migrate(JSON.parse(s));
    for (const k of ["myplan_v16","myplan_v15","myplan_v11","miplan_v9"]) {
      const o = localStorage.getItem(k);
      if (o) return migrate(JSON.parse(o));
    }
    return migrate(DD);
  } catch { return migrate(DD); }
};

const saveData = data => {
  localStorage.setItem(SK, JSON.stringify(data));
};
