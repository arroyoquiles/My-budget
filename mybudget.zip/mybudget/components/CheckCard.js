// ── Shared style helpers (referenced from app globals) ────────────────────────
// mkINP, mkBTN, mkCARD, fmt, n, fmd, gdf, getDU, gds, DEST, CC, CICONS, CATCOLORS, DORDER
// are all defined globally in app.js / the inline script.

// ── LimitBar ──────────────────────────────────────────────────────────────────
const LimitBar = memo(({balance, limite, T}) => {
  const pct   = limite > 0 ? Math.min(100, Math.round((n(balance)/n(limite))*100)) : 0;
  const color = pct >= 90 ? "#f85149" : pct >= 70 ? "#d29922" : "#3fb950";
  return (
    <div style={{marginBottom:12}}>
      <div style={{display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:5}}>
        <span style={{color:T.muted}}>Used {fmt(balance)} of {fmt(limite)}</span>
        <span style={{color, fontWeight:700}}>{pct}% {pct>=90?"🔴 Maxed":pct>=70?"🟡 High":"🟢 Good"}</span>
      </div>
      <div style={{height:9, background:T.surface2, borderRadius:8, overflow:"hidden"}}>
        <div style={{height:"100%", width:`${pct}%`, background:color, borderRadius:8, transition:"width 0.5s"}}/>
      </div>
    </div>
  );
});

// ── DragList ──────────────────────────────────────────────────────────────────
const DragList = memo(({items, onReorder, renderItem}) => {
  const [drag, setDrag] = useState(null), [over, setOver] = useState(null);
  const refs = useRef([]), ti = useRef(null), moved = useRef(false);
  const commit = (f, t) => {
    if (f !== null && t !== null && f !== t) {
      const c = [...items]; const d = c.splice(f,1)[0]; c.splice(t,0,d); onReorder(c);
    }
    setDrag(null); setOver(null);
  };
  const onTS = (e, i) => { ti.current = i; moved.current = false; };
  const onTM = (e, i) => {
    moved.current = true; e.preventDefault(); e.stopPropagation(); setDrag(i);
    const y = e.touches[0].clientY; let best = i, mn = Infinity;
    refs.current.forEach((r, idx) => {
      if (!r) return;
      const rc = r.getBoundingClientRect();
      const d  = Math.abs(y - (rc.top + rc.height/2));
      if (d < mn) { mn = d; best = idx; }
    });
    setOver(best);
  };
  const onTE = () => {
    if (moved.current) commit(ti.current, over);
    ti.current = null; moved.current = false; setDrag(null); setOver(null);
  };
  return (
    <div>
      {items.map((item, i) => (
        <div key={item.id} ref={el=>refs.current[i]=el} style={{opacity:drag===i?0.35:1, transition:"opacity 0.1s"}}>
          {renderItem(item, i, {onTouchStart:e=>onTS(e,i), onTouchMove:e=>onTM(e,i), onTouchEnd:onTE})}
        </div>
      ))}
    </div>
  );
});

// ── GastoItem ─────────────────────────────────────────────────────────────────
const GastoItem = memo(({item, pid, editId, setEditId, tarjetas, onCycle, onLongPress, onUpdate, onRemove, touch, T}) => {
  const dest = gds(item.destino, item.tarjetaRef);
  const INP = mkINP(T), BTN = mkBTN(), CARD = mkCARD(T);
  const pressTimer = useRef(null);
  const hTS = () => { pressTimer.current = setTimeout(() => onLongPress(item.id), 500); };
  const hTE = () => clearTimeout(pressTimer.current);

  if (editId === item.id) return (
    <div style={{marginBottom:8, ...CARD, padding:"14px", border:`1px solid ${T.accent}`}}>
      <div style={{marginBottom:10}}><div style={{fontSize:10,color:T.muted,marginBottom:5}}>NAME</div><input style={INP} value={item.nombre} onChange={e=>onUpdate(item.id,"nombre",e.target.value)} placeholder="Expense name" autoFocus/></div>
      <div style={{marginBottom:10}}><div style={{fontSize:10,color:T.muted,marginBottom:5}}>AMOUNT ($)</div><input style={INP} type="number" inputMode="decimal" value={item.monto||""} onChange={e=>onUpdate(item.id,"monto",e.target.value)} placeholder="0"/></div>
      <div style={{marginBottom:10}}>
        <div style={{fontSize:10,color:T.muted,marginBottom:5}}>DESTINATION</div>
        <div style={{display:"flex", flexWrap:"wrap", gap:5}}>
          {Object.entries(DEST).map(([k,d]) => (
            <button key={k} style={{...BTN, padding:"5px 9px", fontSize:11, background:item.destino===k?d.bg:"#21262d", color:item.destino===k?d.color:T.muted, border:`1px solid ${item.destino===k?d.border:T.border}`}}
              onMouseDown={e=>{e.preventDefault();onUpdate(item.id,"destino",k);if(k!=="credit_card")onUpdate(item.id,"tarjetaRef","");}}>
              {d.icon} {d.label}
            </button>
          ))}
        </div>
      </div>
      {item.destino==="credit_card" && (
        <div style={{marginBottom:10}}><div style={{fontSize:10,color:T.muted,marginBottom:5}}>WHICH CARD?</div>
          <select style={INP} value={item.tarjetaRef} onChange={e=>onUpdate(item.id,"tarjetaRef",e.target.value)}>
            <option value="">Select...</option>
            {tarjetas.map(t=><option key={t.id} value={t.nombre}>{t.nombre}</option>)}
          </select>
        </div>
      )}
      <div style={{marginBottom:12}}><div style={{fontSize:10,color:T.muted,marginBottom:5}}>DUE DAY (optional)</div><input style={INP} type="number" inputMode="numeric" placeholder="e.g. 7" value={item.diaPago||""} onChange={e=>onUpdate(item.id,"diaPago",e.target.value?parseInt(e.target.value):null)}/></div>
      <div style={{display:"flex", gap:8}}>
        <button style={{...BTN, flex:1, padding:"11px", background:"#238636", color:"#fff", fontSize:14}} onClick={()=>setEditId(null)}>✓ Done</button>
        <button style={{...BTN, padding:"11px 14px", background:"rgba(248,81,73,0.15)", color:"#f85149", fontSize:14}} onClick={()=>{onRemove(item.id);setEditId(null);}}>🗑</button>
      </div>
    </div>
  );

  const stBg     = {pending:"transparent",reserved:"rgba(210,153,34,0.07)",paid:"rgba(63,185,80,0.07)"}[item.state||"pending"];
  const stBorder = {pending:T.border,reserved:"rgba(210,153,34,0.3)",paid:"#2ea043"}[item.state||"pending"];
  return (
    <div style={{marginBottom:7}}>
      <div style={{display:"flex", alignItems:"center", gap:8, padding:"10px 11px", borderRadius:11, background:stBg, border:`1px solid ${stBorder}`, transition:"background 0.15s,border 0.15s"}}>
        <div onTouchStart={touch.onTouchStart} onTouchMove={touch.onTouchMove} onTouchEnd={touch.onTouchEnd}
          style={{display:"flex", flexDirection:"column", gap:3, padding:"6px 5px", flexShrink:0, touchAction:"none", cursor:"grab"}}>
          {[0,1,2].map(l=><div key={l} style={{width:14,height:2,background:T.muted,borderRadius:2}}/>)}
        </div>
        <div onClick={()=>onCycle(item.id)} onTouchStart={hTS} onTouchEnd={hTE}
          style={{width:24,height:24,borderRadius:"50%",flexShrink:0,
            background:item.state==="paid"?"#2ea043":item.state==="reserved"?"rgba(210,153,34,0.25)":"transparent",
            border:`2px solid ${item.state==="paid"?"#2ea043":item.state==="reserved"?"#d29922":T.border}`,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,cursor:"pointer",
            color:item.state==="paid"?"#fff":item.state==="reserved"?"#d29922":T.muted,fontWeight:700}}>
          {item.state==="paid"?"✓":item.state==="reserved"?"◑":""}
        </div>
        <div style={{width:26,height:26,borderRadius:7,background:(CATCOLORS[item.cat]||"#94a3b8")+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0}}>
          {CICONS[item.cat]||"📌"}
        </div>
        <div onClick={()=>onCycle(item.id)} style={{flex:1, minWidth:0, cursor:"pointer"}}>
          <div style={{display:"flex", alignItems:"center", gap:5, flexWrap:"wrap"}}>
            <span style={{fontSize:13,fontWeight:600,color:item.state==="paid"?"#3fb950":item.state==="reserved"?"#d29922":T.text,textDecoration:item.state==="paid"?"line-through":"none",opacity:item.state==="paid"?0.75:1}}>{item.nombre||"Untitled"}</span>
            {item.destino!=="other"&&<span style={{fontSize:9,fontWeight:700,color:dest.color,background:dest.bg,border:`1px solid ${dest.border}`,borderRadius:5,padding:"1px 5px",flexShrink:0}}>{dest.icon} {dest.label}</span>}
          </div>
          <div style={{fontSize:10,color:item.state==="paid"?"#3fb950":item.state==="reserved"?"#d29922":T.muted,marginTop:1}}>
            {item.state==="paid"?"✅ Paid":item.state==="reserved"?"◑ Reserved":"○ Pending"}
            {item.diaPago&&item.state!=="paid"&&(()=>{const d=gdf(item.diaPago);return d?<span> · due {fmd(d)}</span>:null;})()}
          </div>
        </div>
        <div style={{fontFamily:"monospace",fontWeight:700,fontSize:13,color:item.state==="paid"?"#3fb950":item.state==="reserved"?"#d29922":dest.color||"#f85149",flexShrink:0}}>{fmt(item.monto)}</div>
        <button style={{...mkBTN(),background:"transparent",color:T.muted,padding:"4px 5px",fontSize:13,flexShrink:0}} onClick={e=>{e.stopPropagation();setEditId(item.id);}}>✏️</button>
      </div>
    </div>
  );
});

// ── DestinoSummary ────────────────────────────────────────────────────────────
const DestinoSummary = memo(({gastos, T}) => {
  const bd = {};
  gastos.forEach(g => {
    const k = g.destino==="credit_card" ? (g.tarjetaRef||"Credit Card") : g.destino;
    if (!bd[k]) bd[k] = {total:0, d:g.destino, r:g.tarjetaRef};
    bd[k].total += n(g.monto);
  });
  const entries = Object.entries(bd).filter(([,v]) => v.total > 0 && v.d !== "other");
  if (!entries.length) return null;
  return (
    <div style={{marginBottom:14}}>
      <div style={{fontSize:10, color:T.muted, letterSpacing:1.5, fontWeight:700, marginBottom:8}}>BREAKDOWN BY DESTINATION</div>
      <div style={{border:`1px solid ${T.border}`, borderRadius:12, overflow:"hidden"}}>
        {entries.map(([k,v],i) => {
          const d = gds(v.d, v.r);
          return (
            <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 12px",background:i%2===0?T.surface:T.bg,borderBottom:i<entries.length-1?`1px solid ${T.border}`:"none"}}>
              <span style={{fontSize:12, color:d.color, fontWeight:600}}>{d.icon} {d.label}</span>
              <span style={{fontFamily:"monospace", fontWeight:800, color:d.color, fontSize:13}}>{fmt(v.total)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
});
