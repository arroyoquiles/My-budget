// ── CalendarView component ────────────────────────────────────────────────────
// Depends on globals: fmt, fmd, getDU, gdf, gds, CICONS, CC, T (passed as prop),
// upcomingPaydays, monthPeriods, getPGastos, globalCheckAmount (passed as props)

const CalendarView = ({T, theme, calView, setCalView, upcomingPaydays, monthPeriods, getPGastos, globalCheckAmount, data, BTN, CARD}) => {
  const hoy  = new Date(); hoy.setHours(0,0,0,0);
  const en35 = new Date(hoy.getTime() + 35*86400000);
  const events = [];

  // Paydays
  upcomingPaydays.slice(0,6).forEach(pd => {
    if (pd <= en35) events.push({fecha:pd, tipo:"payday", label:"💵 Payday", color:"#3fb950", monto:globalCheckAmount});
  });

  // Card/loan due dates and cutoffs
  [...data.tarjetas, ...(data.loans||[])].forEach(d => {
    if (d.fechaPago) {
      const c = new Date(hoy.getFullYear(), hoy.getMonth(), parseInt(d.fechaPago));
      if (c < hoy) c.setMonth(c.getMonth()+1);
      if (c <= en35) {
        const tc = CC[d.nombre] || {};
        events.push({fecha:c, tipo:"payment", label:`${tc.dot||"💳"} ${d.nombre}`, color:tc.color||"#ec4899", monto:d.minimo, dias:getDU(d.fechaPago)});
      }
    }
    if (d.fechaCorte) {
      const cc = new Date(hoy.getFullYear(), hoy.getMonth(), parseInt(d.fechaCorte));
      if (cc < hoy) cc.setMonth(cc.getMonth()+1);
      if (cc <= en35) events.push({fecha:cc, tipo:"cutoff", label:`✂️ Cutoff ${d.nombre}`, color:T.muted, subtipo:"cutoff"});
    }
  });

  // Expense due days
  const seen = new Set();
  monthPeriods.flatMap(p => getPGastos(p.id)).forEach(g => {
    if (!g.diaPago || seen.has(g.nombre) || g.destino==="credit_card" || g.destino==="temp" || g.destino==="other") return;
    seen.add(g.nombre);
    const c = new Date(hoy.getFullYear(), hoy.getMonth(), parseInt(g.diaPago));
    if (c < hoy) c.setMonth(c.getMonth()+1);
    if (c <= en35) {
      const d = gds(g.destino, g.tarjetaRef);
      events.push({fecha:c, tipo:"expense", label:`${CICONS[g.cat]||"📌"} ${g.nombre}`, color:d.color, monto:g.monto});
    }
  });

  events.sort((a,b) => a.fecha - b.fecha);

  const grupos = {};
  events.forEach(e => {
    const k = e.fecha.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"});
    if (!grupos[k]) grupos[k] = {fecha:e.fecha, items:[]};
    grupos[k].items.push(e);
  });

  const mo  = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const yr  = hoy.getFullYear(), mth = hoy.getMonth();
  const fd  = new Date(yr, mth, 1).getDay();
  const dim = new Date(yr, mth+1, 0).getDate();
  const ebd = {};
  events.forEach(e => {
    if (e.fecha.getMonth()===mth && e.fecha.getFullYear()===yr) {
      const d = e.fecha.getDate();
      if (!ebd[d]) ebd[d] = [];
      ebd[d].push(e);
    }
  });

  return (
    <div className="anim">
      <div style={{display:"flex", gap:7, marginBottom:14}}>
        <button style={{...BTN,flex:1,padding:"8px",fontSize:12,background:calView==="list"?T.accent:T.surface2,color:calView==="list"?(theme==="dark"?"#0d1117":"#fff"):T.muted,border:`1px solid ${calView==="list"?T.accent:T.border}`}} onClick={()=>setCalView("list")}>📋 List</button>
        <button style={{...BTN,flex:1,padding:"8px",fontSize:12,background:calView==="cal"?T.accent:T.surface2,color:calView==="cal"?(theme==="dark"?"#0d1117":"#fff"):T.muted,border:`1px solid ${calView==="cal"?T.accent:T.border}`}} onClick={()=>setCalView("cal")}>📅 Month</button>
      </div>

      {calView==="cal" ? (
        <div style={{...CARD, padding:"14px"}}>
          <div style={{textAlign:"center", fontWeight:700, fontSize:14, marginBottom:12}}>{mo[mth]} {yr}</div>
          <div style={{display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:2, marginBottom:12}}>
            {["S","M","T","W","T","F","S"].map((d,i) => <div key={i} style={{textAlign:"center",fontSize:10,color:T.muted,fontWeight:700,padding:"4px 0"}}>{d}</div>)}
            {[...Array(fd).fill(null), ...Array.from({length:dim},(_,i)=>i+1)].map((d,i) => {
              if (!d) return <div key={i}/>;
              const isT = d === hoy.getDate();
              const evts = ebd[d] || [];
              const dots = [...new Set(evts.map(e=>e.color))].slice(0,3);
              return (
                <div key={i} style={{aspectRatio:"1",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",borderRadius:8,background:isT?"rgba(88,166,255,0.2)":"transparent",border:isT?"1px solid #58a6ff":"1px solid transparent"}}>
                  <span style={{fontSize:12,fontWeight:isT?800:400,color:isT?"#58a6ff":evts.length?T.text:T.muted}}>{d}</span>
                  {dots.length>0&&<div style={{display:"flex",gap:2,marginTop:2}}>{dots.map((c,ci)=><div key={ci} style={{width:4,height:4,borderRadius:"50%",background:c}}/>)}</div>}
                </div>
              );
            })}
          </div>
          {Object.entries(ebd).sort(([a],[b])=>+a-+b).map(([day,evts]) => (
            <div key={day} style={{marginBottom:8}}>
              <div style={{fontSize:10,color:T.muted,fontWeight:700,marginBottom:4}}>{mo[mth].slice(0,3)} {day}</div>
              {evts.map((ev,i) => (
                <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 10px",borderRadius:8,background:ev.subtipo==="cutoff"?"transparent":T.bg,border:`1px solid ${ev.subtipo==="cutoff"?T.border:T.surface2}`,marginBottom:3,opacity:ev.subtipo==="cutoff"?0.5:1}}>
                  <div style={{width:6,height:6,borderRadius:"50%",background:ev.color,flexShrink:0}}/>
                  <div style={{flex:1,fontSize:11}}>{ev.label}</div>
                  {ev.monto&&<div style={{fontFamily:"monospace",fontWeight:700,fontSize:11,color:ev.tipo==="payday"?"#3fb950":"#f85149"}}>{ev.tipo==="payday"?"+":"-"}{fmt(ev.monto)}</div>}
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : (
        <>
          <div style={{fontSize:11, color:T.muted, marginBottom:12}}>Next 35 days</div>
          {Object.entries(grupos).map(([dk,g]) => {
            const dh = Math.ceil((g.fecha - hoy) / 86400000);
            const isH = dh === 0;
            return (
              <div key={dk} style={{marginBottom:12}}>
                <div style={{display:"flex", alignItems:"center", gap:8, marginBottom:5}}>
                  <div style={{fontFamily:"monospace",fontSize:12,fontWeight:700,color:isH?"#58a6ff":dh<=3?"#f85149":T.text}}>{dk}</div>
                  {isH&&<div style={{padding:"2px 6px",borderRadius:8,background:"rgba(88,166,255,0.2)",color:"#58a6ff",fontSize:9,fontWeight:700}}>TODAY</div>}
                  {!isH&&dh>0&&<div style={{fontSize:10,color:T.muted}}>in {dh}d</div>}
                </div>
                {g.items.map((ev,i) => (
                  <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 11px",borderRadius:10,background:ev.subtipo==="cutoff"?"transparent":T.surface,border:`1px solid ${ev.subtipo==="cutoff"?T.border:ev.dias&&ev.dias<=3?"rgba(248,81,73,0.4)":T.border}`,marginBottom:4,opacity:ev.subtipo==="cutoff"?0.5:1}}>
                    <div style={{width:7,height:7,borderRadius:"50%",background:ev.color,flexShrink:0}}/>
                    <div style={{flex:1,fontSize:12}}>{ev.label}</div>
                    {ev.monto&&<div style={{fontFamily:"monospace",fontWeight:700,fontSize:12,color:ev.tipo==="payday"?"#3fb950":"#f85149"}}>{ev.tipo==="payday"?"+":"-"}{fmt(ev.monto)}</div>}
                  </div>
                ))}
              </div>
            );
          })}
        </>
      )}
    </div>
  );
};
