// ── HistoryView component ─────────────────────────────────────────────────────

const HistoryView = ({data, T, CARD}) => {
  return (
    <div className="anim">
      <div style={{background:"rgba(88,166,255,0.05)",border:"1px solid rgba(88,166,255,0.15)",borderRadius:11,padding:"11px 14px",marginBottom:12,fontSize:11,color:T.muted,lineHeight:1.6}}>
        💡 <strong style={{color:T.accent}}>Monthly Snapshot</strong> — save at end of each month.<br/>
        <strong style={{color:T.accent}}>Reset Cycle</strong> — use in each Check tab when a new paycheck arrives. Temporary &amp; quick expenses are auto-removed.
      </div>
      {(!data.snapshots || data.snapshots.length === 0) ? (
        <div style={{...CARD, padding:"34px 20px", textAlign:"center"}}>
          <div style={{fontSize:32, marginBottom:8}}>📆</div>
          <div style={{fontWeight:700, marginBottom:4}}>No history yet</div>
          <div style={{color:T.muted, fontSize:12}}>Go to Overview and save a monthly snapshot</div>
        </div>
      ) : data.snapshots.map(h => (
        <div key={h.id} style={{...CARD, padding:"13px 16px", marginBottom:8}}>
          <div style={{display:"flex", justifyContent:"space-between", marginBottom:10}}>
            <div style={{fontSize:12, color:T.muted}}>{h.fecha}</div>
          </div>
          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:7}}>
            {[
              {l:"Surplus",    v:fmt(h.sobrante),  c:n(h.sobrante)>=0?"#3fb950":"#f85149"},
              {l:"Total Debt", v:fmt(h.deuda),      c:"#d29922"},
              {l:"Cash",       v:fmt(h.cash||0),    c:"#58a6ff"},
            ].map(s => (
              <div key={s.l} style={{background:T.bg, borderRadius:8, padding:"8px 10px"}}>
                <div style={{fontSize:9, color:T.muted, marginBottom:3}}>{s.l}</div>
                <div style={{fontFamily:"monospace", fontWeight:700, color:s.c, fontSize:13}}>{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
