// ── PotCard (Savings Goal section) ───────────────────────────────────────────

const PotCard = ({data, setData, pots, toast_, T, INP, BTN, CARD, fmt, n}) => {
  return (
    <div style={{...CARD, padding:"13px 16px", marginBottom:12, borderColor:data.ahorro?.activo?"#3fb950":T.border}}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:data.ahorro?.activo?10:0}}>
        <div style={{fontSize:10, color:T.muted, letterSpacing:1.5, fontWeight:700}}>🏦 SAVINGS GOAL</div>
        <div style={{display:"flex", alignItems:"center", gap:8}}>
          {!data.ahorro?.activo && <span style={{fontSize:10, color:T.muted}}>Off</span>}
          <div
            onClick={()=>setData(p=>({...p, ahorro:{...(p.ahorro||{}), activo:!p.ahorro?.activo}}))}
            style={{width:36,height:20,borderRadius:10,background:data.ahorro?.activo?"#238636":T.surface2,position:"relative",cursor:"pointer",transition:"background 0.2s"}}>
            <div style={{width:16,height:16,borderRadius:"50%",background:"#fff",position:"absolute",top:2,left:data.ahorro?.activo?18:2,transition:"left 0.2s"}}/>
          </div>
        </div>
      </div>

      {data.ahorro?.activo && (<>
        <div style={{background:"rgba(63,185,80,0.08)",border:"1px solid rgba(63,185,80,0.2)",borderRadius:10,padding:"10px 14px",marginBottom:10,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:9, color:T.muted}}>IN SAVINGS POT</div>
            <div style={{fontFamily:"monospace", fontSize:22, fontWeight:800, color:"#3fb950"}}>{fmt(n(pots.savings_acct)||0)}</div>
          </div>
          <button style={{...BTN,padding:"6px 11px",background:"rgba(248,81,73,0.1)",color:"#f85149",fontSize:11,border:"1px solid rgba(248,81,73,0.25)"}}
            onClick={()=>{if(window.confirm("Reset savings pot to $0? This will also revert all savings movements.")){
              setData(p=>({...p,pots:{...p.pots,savings_acct:0},potMovements:(p.potMovements||[]).filter(m=>m.potKey!=="savings_acct"),ahorro:{...(p.ahorro||{}),acumulado:0,historial:[]}}));
            }}}>Reset</button>
        </div>

        <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:T.muted,marginBottom:4}}>
          <span>Goal: {fmt(n(data.ahorro?.meta)||500)}</span>
          <span style={{color:"#3fb950",fontWeight:700}}>
            {(n(data.ahorro?.meta)||500)>0 ? Math.round((n(pots.savings_acct||0)/n(data.ahorro?.meta||500))*100) : 0}%
          </span>
        </div>
        <div style={{height:7,background:T.surface2,borderRadius:8,overflow:"hidden",marginBottom:10}}>
          <div style={{height:"100%",width:`${(n(data.ahorro?.meta)||500)>0?Math.min(100,Math.round((n(pots.savings_acct||0)/n(data.ahorro?.meta||500))*100)):0}%`,background:"linear-gradient(90deg,#238636,#3fb950)",borderRadius:8}}/>
        </div>

        <div style={{display:"flex", gap:7}}>
          <div style={{flex:1}}>
            <div style={{fontSize:9,color:T.muted,marginBottom:4}}>GOAL ($)</div>
            <input style={{...INP,fontSize:14}} type="number" inputMode="decimal" value={data.ahorro?.meta||500} onChange={e=>setData(p=>({...p,ahorro:{...(p.ahorro||{}),meta:e.target.value}}))}/>
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:9,color:T.muted,marginBottom:4}}>ADD TO SAVINGS</div>
            <div style={{display:"flex", gap:5}}>
              <input style={{...INP,fontSize:14}} type="number" inputMode="decimal" placeholder="0" value={data._sa||""} onChange={e=>setData(p=>({...p,_sa:e.target.value}))}/>
              <button style={{...BTN,padding:"8px 10px",background:"#238636",color:"#fff",fontSize:14,flexShrink:0}}
                onMouseDown={e=>{
                  e.preventDefault();
                  const m=parseFloat(data._sa);
                  if(m>0){
                    const mvId=Date.now();
                    setData(p=>({...p,pots:{...p.pots,savings_acct:n(p.pots?.savings_acct||0)+m},potMovements:[...(p.potMovements||[]),{id:mvId,potKey:"savings_acct",amount:m,date:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric"}),note:"Savings deposit"}],_sa:""}));
                    toast_(`💚 +${fmt(m)} saved`);
                  }
                }}> + </button>
            </div>
          </div>
        </div>
      </>)}
    </div>
  );
};
